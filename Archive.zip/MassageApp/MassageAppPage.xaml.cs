﻿using Xamarin.Forms;

namespace MassageApp
{
	public partial class MassageAppPage : ContentPage
	{
		public MassageAppPage()
		{
			InitializeComponent();
		}
	}
}

