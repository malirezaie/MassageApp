﻿using Xamarin.Forms;

namespace MassageApp
{
	public class TodayPageCS : ContentPage
	{
		public TodayPageCS ()
		{
			//if (Device.OS == TargetPlatform.iOS)
			//{
				Icon = "today.png";
			//}
			Title = "Today";
			Content = new StackLayout { 
				Children = {
					new Label {
						Text = "Today's appointments go here",
						HorizontalOptions = LayoutOptions.Center,
						VerticalOptions = LayoutOptions.CenterAndExpand
					}
				}
			};
		}
	}
}
